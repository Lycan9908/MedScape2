package com.example.medscape;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.example.medscape.databinding.ActivityServiceBinding;

public class ServiceActivity extends AppCompatActivity
{
 ActivityServiceBinding binding;
 String path;
 @Override
    protected void onCreate(Bundle savedInstanceState) {
     super.onCreate(savedInstanceState);
     binding=ActivityServiceBinding.inflate(getLayoutInflater());
     setContentView(binding.getRoot());
     clickListeners();
 }

    private void clickListeners() {
     binding.upload.setOnClickListener(v -> {
         if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED){
             Intent intent=new Intent();
             intent.setType("Image/*");
             intent.setAction(Intent.ACTION_GET_CONTENT);
             startActivityForResult(intent,10);
         }else {
             ActivityCompat.requestPermissions(ServiceActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
         }
     });
     binding.savebtn.setOnClickListener(v -> {

     });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==10&&resultCode==Activity.RESULT_OK){
            Uri uri=data.getData();
            Context context=ServiceActivity.this;
            path=RealPathUtil.getRealPath(context,uri);
            Bitmap bitmap= BitmapFactory.decodeFile(path);
            binding.pickedimage.setImageBitmap(bitmap);
        }
    }
}