package com.example.medscape;

import android.view.LayoutInflater;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<ModelClass> userList;
    public Adapter(List<ModelClass>userList){this.userList=userList;}


    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_design,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        int resource=userList.get(position).getMedview1();
        String name=userList.get(position).getTextavailable();
        String line=userList.get(position).getDivider();

        holder.setData(resource,name,line);
    }

    @Override
    public int getItemCount()
    {
        return userList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView medview1;
        private TextView textavailable;
        private TextView divider;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            medview1=itemView.findViewById(R.id.medview1);
            textavailable=itemView.findViewById(R.id.textavailable);
            divider=itemView.findViewById(R.id.divider);
        }

        public void setData(int resource, String name, String line) {
            medview1.setImageResource(resource);
            textavailable.setText(name);
            divider.setText(line);

        }
    }
}

