package com.example.medscape;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface API {

    @FormUrlEncoded
    @POST("api/login/")
    Call<List<model>> login(
            @Field("email") String email,
            @Field("password") String password
    );
    @FormUrlEncoded
    @POST("api/register/")
    Call<regmodel>register(
            @Field("full_name")String full_name,
            @Field("email")String email,
            @Field("password")String password,
            @Field("password2")String password2
    );
}
