package com.example.medscape;

public class ModelClass {

    private int medview1;
    private String textavailable;
    private String divider;

    ModelClass(int medview1,String textavailable,String divider){
        this.medview1=medview1;
        this.textavailable=textavailable;
        this.divider=divider;
    }

    public int getMedview1()
    {
        return medview1;
    }

    public String getTextavailable()
    {
        return textavailable;
    }

    public String getDivider()
    {
        return divider;
    }
}
