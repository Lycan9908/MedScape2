package com.example.medscape;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class client {
    private static client retrofitClient;
    private static Retrofit retrofit;

    private client() {
        retrofit = new Retrofit.Builder()
                .baseUrl("https://register-login-api.shivila.in")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static synchronized client getInstance() {
        if (retrofitClient == null) {
            retrofitClient = new client();
        }
        return retrofitClient;
    }

    public API getApi() {
        return retrofit.create(API.class);
    }
}