package com.example.medscape;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.medscape.databinding.ActivityMainBinding;
import com.example.medscape.databinding.ActivityRegistrationBinding;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Field;

public class RegistrationActivity extends AppCompatActivity {
    private ActivityRegistrationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegistrationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                register();
                vollyLogin();
            }
        });

    }

    private void vollyLogin() {

// ...

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://register-login-api.shivila.in/accounts/api/register/";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(RegistrationActivity.this, "successful", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(RegistrationActivity.this,ServiceActivity.class);
                        startActivity(intent);
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(RegistrationActivity.this, "Failed", Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email", binding.Email.getText().toString());
                params.put("password", binding.password.getText().toString());
                params.put("full_name", binding.fullName.getText().toString());
                params.put("password2", binding.password2.getText().toString());
                return params;
            }
        };
        queue.add(stringRequest);
    }

    private void register() {
        Call<regmodel> call = client.getInstance().getApi().register(binding.fullName.getText().toString(),
                binding.Email.getText().toString(), binding.password.getText().toString(), binding.password2.getText().toString());
        System.out.println("Email " + binding.Email.getText().toString());
        call.enqueue(new Callback<regmodel>() {
            @Override
            public void onResponse(Call<regmodel> call, Response<regmodel> response) {
                regmodel re = response.body();

                /*
                i
                 */

                if (response.isSuccessful()) {

                    System.out.println("response " + re.getEmail());
//                    if ("Only yourmail@shivila.com Accepted".equals(re.email))
//                    if ("Username Already Exist. Try Another One".equals(re.username.get(0).toString())) {
//                        Toast.makeText(RegistrationActivity.this, re.username.get(0).toString(), Toast.LENGTH_SHORT).show();
//                    } else {
//                        System.out.println("response "+re.username.toString());
////                        Toast.makeText(RegistrationActivity.this, "registered!!" + re.getMessage(), Toast.LENGTH_SHORT).show();
////                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
////                        startActivity(intent);
//                    }
                }
            }

            @Override
            public void onFailure(Call<regmodel> call, Throwable t) {
                Toast.makeText(RegistrationActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}